import { motion } from "motion/react";
import { ArrowRight, Download, ExternalLink, Mail, Phone } from "lucide-react";
import { Button, buttonVariants } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { PROFILE, EXPERIENCE, EDUCATION, SKILLS, PROJECTS } from "@/src/constants";
import { cn } from "@/lib/utils";

export function Hero() {
  return (
    <section id="about" className="section-padding min-h-screen flex flex-col justify-center relative overflow-hidden bg-mesh">
      <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 pointer-events-none"></div>
      
      <div className="max-w-6xl relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        >
          <Badge variant="outline" className="mb-8 px-4 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-[0.3em] border-white/20 text-white/60">
            Systems Analyst • Data Engineer
          </Badge>
          
          <h1 className="font-serif text-6xl md:text-8xl lg:text-9xl font-bold tracking-tight mb-8 leading-[0.9] text-gradient">
            Building <span className="italic font-normal text-accent">Intelligent</span> <br />
            Digital <span className="text-white">Infrastructures.</span>
          </h1>
          
          <p className="text-lg md:text-2xl text-white/60 max-w-3xl mb-12 leading-relaxed font-light text-balance">
            I am <span className="text-white font-medium">{PROFILE.name}</span>. 
            I architect secure, high-performance systems and bridge the gap between 
            complex data and actionable intelligence.
          </p>
          
          <div className="flex flex-wrap gap-6">
            <a 
              href="#projects" 
              className={cn(
                buttonVariants({ size: "lg" }), 
                "rounded-full px-12 py-8 text-lg font-medium bg-white text-black hover:scale-105 transition-transform duration-300"
              )}
            >
              Explore My Work
            </a>
            <a 
              href="#contact" 
              className={cn(
                buttonVariants({ variant: "outline", size: "lg" }), 
                "rounded-full px-12 py-8 text-lg font-medium border-white/20 text-white hover:bg-white/10 transition-all duration-300"
              )}
            >
              Get In Touch
            </a>
          </div>
        </motion.div>
      </div>
      
      {/* Decorative element */}
      <motion.div 
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 0.3, scale: 1 }}
        transition={{ duration: 2, repeat: Infinity, repeatType: "reverse" }}
        className="absolute -bottom-24 -right-24 w-96 h-96 bg-accent rounded-full blur-[120px] pointer-events-none"
      />
    </section>
  );
}

export function Experience() {
  return (
    <section id="experience" className="section-padding bg-secondary/20">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
          <div className="lg:col-span-1">
            <h2 className="text-sm font-bold uppercase tracking-[0.2em] text-muted-foreground mb-4">The Journey</h2>
            <h3 className="font-serif text-4xl font-bold mb-6">Professional Experience</h3>
            <p className="text-muted-foreground leading-relaxed">
              A decade of growth from technical support to systems analysis, building a robust foundation in secure institutional systems.
            </p>
          </div>
          
          <div className="lg:col-span-2 space-y-12">
            {EXPERIENCE.map((exp, index) => (
              <motion.div
                key={exp.company}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="relative pl-8 border-l border-border"
              >
                <div className="absolute left-[-5px] top-0 w-[10px] h-[10px] rounded-full bg-primary" />
                <p className="text-xs font-mono text-muted-foreground mb-2 uppercase tracking-widest">{exp.period}</p>
                <h4 className="text-xl font-bold mb-1">{exp.role}</h4>
                <p className="text-sm font-medium text-primary/60 mb-4">{exp.company}</p>
                <p className="text-muted-foreground text-sm leading-relaxed mb-4 max-w-xl">
                  {exp.description}
                </p>
                <div className="flex flex-wrap gap-2">
                  {exp.skills.map(skill => (
                    <Badge key={skill} variant="secondary" className="rounded-full text-[10px] font-normal">
                      {skill}
                    </Badge>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

export function Education() {
  return (
    <section className="section-padding">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
          <div className="lg:col-span-1">
            <h2 className="text-sm font-bold uppercase tracking-[0.2em] text-muted-foreground mb-4">Foundation</h2>
            <h3 className="font-serif text-4xl font-bold mb-6">Academic Background</h3>
          </div>
          
          <div className="lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-8">
            {EDUCATION.map((edu, index) => (
              <motion.div
                key={edu.school}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="h-full border-border/50 shadow-none bg-secondary/10">
                  <CardHeader>
                    <p className="text-xs font-mono text-muted-foreground mb-2">{edu.period}</p>
                    <CardTitle className="text-lg leading-tight">{edu.degree}</CardTitle>
                    <CardDescription className="font-medium text-primary/70">{edu.school}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Badge className="rounded-full bg-primary/10 text-primary border-none">
                      {edu.status}
                    </Badge>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

export function Skills() {
  return (
    <section id="skills" className="section-padding">
      <div className="max-w-7xl mx-auto">
        <div className="mb-16">
          <h2 className="text-sm font-bold uppercase tracking-[0.2em] text-muted-foreground mb-4">Expertise</h2>
          <h3 className="font-serif text-4xl md:text-5xl font-bold">Technical Toolkit</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          <div className="space-y-8">
            <h4 className="text-xl font-bold border-b border-border pb-4">Programming</h4>
            <div className="flex flex-wrap gap-3">
              {SKILLS.programming.map(skill => (
                <Badge key={skill} className="px-4 py-2 rounded-lg text-sm bg-secondary text-secondary-foreground hover:bg-primary hover:text-primary-foreground transition-all cursor-default">
                  {skill}
                </Badge>
              ))}
            </div>
          </div>

          <div className="space-y-8">
            <h4 className="text-xl font-bold border-b border-border pb-4">Specialized</h4>
            <div className="flex flex-wrap gap-3">
              {SKILLS.specialized.map(skill => (
                <Badge key={skill} className="px-4 py-2 rounded-lg text-sm bg-secondary text-secondary-foreground hover:bg-primary hover:text-primary-foreground transition-all cursor-default">
                  {skill}
                </Badge>
              ))}
            </div>
          </div>

          <div className="space-y-8">
            <h4 className="text-xl font-bold border-b border-border pb-4">Tools & Methods</h4>
            <div className="flex flex-wrap gap-3">
              {SKILLS.tools.map(skill => (
                <Badge key={skill} className="px-4 py-2 rounded-lg text-sm bg-secondary text-secondary-foreground hover:bg-primary hover:text-primary-foreground transition-all cursor-default">
                  {skill}
                </Badge>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export function Projects() {
  return (
    <section id="projects" className="section-padding bg-[#050505]">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-20 gap-8">
          <div className="max-w-2xl">
            <h2 className="text-accent text-xs font-bold uppercase tracking-[0.4em] mb-4">Selected Works</h2>
            <h3 className="font-serif text-5xl md:text-7xl font-bold text-white leading-none">Developed <br /> <span className="italic font-normal text-white/40">Systems.</span></h3>
          </div>
          <p className="text-white/40 max-w-xs text-sm leading-relaxed">
            Architecting robust solutions for banking, research, and government infrastructure.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          {PROJECTS.map((project, index) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="group"
            >
              <Card className="glass-card h-full flex flex-col overflow-hidden transition-all duration-500 hover:border-accent/50 group-hover:shadow-[0_0_50px_-12px_rgba(59,130,246,0.3)]">
                <div className="p-8 md:p-12 flex flex-col h-full">
                  <div className="flex justify-between items-start mb-12">
                    <span className="text-[10px] font-mono text-accent uppercase tracking-[0.2em] px-3 py-1 border border-accent/30 rounded-full">
                      {project.category}
                    </span>
                    <ExternalLink size={20} className="text-white/20 group-hover:text-accent transition-colors" />
                  </div>
                  
                  <h4 className="font-serif text-3xl md:text-4xl font-bold text-white mb-6 group-hover:text-accent transition-colors">
                    {project.title}
                  </h4>
                  
                  <p className="text-white/50 text-base leading-relaxed mb-10 flex-grow">
                    {project.description}
                  </p>
                  
                  <div className="flex flex-wrap gap-3 mt-auto">
                    {project.tags.map(tag => (
                      <span key={tag} className="text-[10px] font-mono py-1.5 px-3 bg-white/5 text-white/40 rounded-md border border-white/5 group-hover:border-white/10 transition-colors">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

export function Contact() {
  return (
    <section id="contact" className="section-padding">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
          <div>
            <h2 className="text-sm font-bold uppercase tracking-[0.2em] text-muted-foreground mb-4">Get in touch</h2>
            <h3 className="font-serif text-5xl md:text-6xl font-bold mb-8">Let's build something together.</h3>
            <p className="text-lg text-muted-foreground mb-12 max-w-md">
              Whether you have a question about my experience or just want to say hi, my inbox is always open.
            </p>
            
            <div className="space-y-6">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-secondary rounded-full">
                  <Mail size={20} />
                </div>
                <div>
                  <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Email</p>
                  <p className="font-medium">{PROFILE.email}</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="p-3 bg-secondary rounded-full">
                  <Phone size={20} />
                </div>
                <div>
                  <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Phone</p>
                  <p className="font-medium">{PROFILE.phone}</p>
                </div>
              </div>
            </div>
          </div>

          <Card className="p-8 border-border shadow-sm">
            <form className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest">Name</label>
                  <Input placeholder="Your name" className="rounded-none border-0 border-b border-border focus-visible:ring-0 focus-visible:border-primary px-0" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest">Email</label>
                  <Input placeholder="Your email" type="email" className="rounded-none border-0 border-b border-border focus-visible:ring-0 focus-visible:border-primary px-0" />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-widest">Subject</label>
                <Input placeholder="What's this about?" className="rounded-none border-0 border-b border-border focus-visible:ring-0 focus-visible:border-primary px-0" />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-widest">Message</label>
                <Textarea placeholder="Tell me more..." className="min-h-[150px] rounded-none border-0 border-b border-border focus-visible:ring-0 focus-visible:border-primary px-0 resize-none" />
              </div>
              <Button className="w-full rounded-full py-6 text-lg font-serif italic">
                Send Message
              </Button>
            </form>
          </Card>
        </div>
      </div>
    </section>
  );
}
