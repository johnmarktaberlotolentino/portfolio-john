export const PROFILE = {
  name: "John Mark Taberlo Tolentino",
  title: "Information Systems Analyst | Data Science Enthusiast",
  email: "johnmarktaberlotolentino@gmail.com",
  phone: "09060221066",
  location: "Valenzuela City, Philippines",
  summary: "A seasoned Information Systems Analyst with over a decade of experience across the financial and scientific sectors. Currently a Science Research Specialist I at ITDI-DOST, specializing in system analysis, cybersecurity, and data engineering. Pursuing advanced studies in Data Science to bridge the gap between traditional IT infrastructure and modern data-driven solutions.",
  socials: {
    linkedin: "https://www.linkedin.com/in/john-mark-tolentino-8210b2168/",
    github: "https://github.com/johnmarktaberlotolentino",
    facebook: "https://www.facebook.com/jmtolentino007",
  }
};

export const EXPERIENCE = [
  {
    company: "Industrial Technology Development Institute (ITDI-DOST)",
    role: "Science Research Specialist I",
    period: "July 2018 - Present",
    description: "Managing complex systems and maintaining high standards of technical precision within a premier government institute. Specialized in system analysis, cybersecurity, and quality assurance.",
    skills: ["System Analysis", "Cybersecurity", "Quality Assurance", "Research"]
  },
  {
    company: "Landbank of the Philippines Service Corporation",
    role: "Programmer",
    period: "October 2016 - May 2018",
    description: "Developed and maintained secure institutional systems and applications for one of the largest banking institutions in the Philippines.",
    skills: ["Application Development", "Banking Systems", "Secure Coding"]
  },
  {
    company: "Alorica Pacific Rim Inc",
    role: "Technical Support Specialist",
    period: "May 2014 - September 2016",
    description: "Provided high-level technical support and troubleshooting for complex IT systems.",
    skills: ["Technical Support", "Troubleshooting", "Customer Service"]
  },
  {
    company: "Aegis PeopleSupport",
    role: "Technical Support Specialist",
    period: "April 2012 - April 2014",
    description: "Initial professional experience in technical support, building a strong foundation in IT infrastructure.",
    skills: ["IT Support", "Infrastructure"]
  }
];

export const EDUCATION = [
  {
    school: "Polytechnic University of the Philippines - Manila",
    degree: "Master of Science in Computer Engineering - Data Science and Engineering",
    period: "Sept 2023 - Present",
    status: "Ongoing (33 units earned)"
  },
  {
    school: "Cagayan State University - Aparri Campus",
    degree: "Bachelor of Science in Information Technology",
    period: "2007 - 2011",
    status: "Cum Laude"
  }
];

export const SKILLS = {
  programming: ["Python", "PHP", "React JS", "JSX", "HTML", "CSS"],
  specialized: ["Data Science", "Machine Learning", "AI", "Cybersecurity", "Penetration Testing"],
  tools: ["Database Management", "System Analysis", "Quality Assurance", "Machine Vision", "OCR"]
};

export const PROJECTS = [
  {
    id: 1,
    title: "Secure Banking Transaction System",
    description: "Developed and maintained core modules for secure institutional banking systems, focusing on data integrity and transaction security during tenure at Landbank.",
    tags: ["PHP", "SQL", "Secure Coding", "Banking"],
    category: "System Development"
  },
  {
    id: 2,
    title: "Automated OCR & Text Extraction Tool",
    description: "Built a machine vision system for automated document processing, utilizing OCR techniques to extract and categorize text from complex government forms.",
    tags: ["Python", "OpenCV", "OCR", "Machine Vision"],
    category: "AI & Vision"
  },
  {
    id: 3,
    title: "Scientific Research Data Warehouse",
    description: "Architected a centralized data repository for scientific research metrics at ITDI-DOST, streamlining data access and reporting for multiple divisions.",
    tags: ["Python", "Data Engineering", "SQL", "System Analysis"],
    category: "Data Engineering"
  },
  {
    id: 4,
    title: "Windows Desktop Utility Suite",
    description: "A collection of custom-built Windows applications designed to automate repetitive administrative tasks and improve workflow efficiency in government operations.",
    tags: ["C#", ".NET", "Windows Dev", "Automation"],
    category: "Desktop Apps"
  }
];
